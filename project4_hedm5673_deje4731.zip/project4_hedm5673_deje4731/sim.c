#include <ctype.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define NUMMEMORY 65536 /* maximum number of data words in memory */
#define NUMREGS 8 /* number of machine registers */

#define ADD 0
#define NAND 1
#define LW 2
#define SW 3
#define BEQ 4
#define JALR 5
#define HALT 6
#define NOOP 7

#define NOOPINSTRUCTION 0x1c00000

enum action_type {cache_to_processor, processor_to_cache, cache_to_memory, memory_to_cache,
			cache_to_nowhere};


typedef struct statestruct {
	int pc;
	int mem[NUMMEMORY];
	int reg[NUMREGS];
	int nummemory;
} statetype;

typedef struct cachestruct {
	int block_size;
	int sets;
	int associativity;
	int *dirty;
	int *valid;
	int *lru;
	int *tag;
	int *data;
} cachetype;

void print_action(int address, int size, enum action_type type){
	printf("transferring word [%i-%i] ", address, address + size -1);
	if(type == cache_to_processor){
		printf("from the cache to the processor\n");
	} else if (type == processor_to_cache){
		printf("from the processor to the cache\n");
	} else if (type == memory_to_cache){
		printf("from the memory to the cache\n");
	} else if (type == cache_to_memory){
		printf("from the cache to the memory\n");
	} else if (type == cache_to_nowhere){
		printf("from the cache to nowhere\n");
	}
}

int field0(int instruction){
	return( (instruction>>19) & 0x7);
}

int field1(int instruction){
	return( (instruction>>16) & 0x7);
}

int field2(int instruction){
	return(instruction & 0xFFFF);
}

int opcode(int instruction){
	return(instruction>>22);
}

void printstate(statetype *stateptr){
	int i;
	printf("\n@@@\nstate:\n");
	printf("\tpc %d\n", stateptr->pc);
	printf("\tmemory:\n");
	for(i = 0; i < stateptr->nummemory; i++){
		printf("\t\tmem[%d]=%d\n", i, stateptr->mem[i]);
	}
	printf("\tregisters:\n");
	for(i = 0; i < NUMREGS; i++){
		printf("\t\treg[%d]=%d\n", i, stateptr->reg[i]);
	}
	printf("end state\n");
}

int signextend(int num){
	// convert a 16-bit number into a 32-bit integer
	if (num & (1<<15) ) {
		num -= (1<<16);
	}
	return num;
}

void print_stats(int n_instrs){
	printf("INSTRUCTIONS: %d\n", n_instrs);
}

int access_cache(cachetype* cache, statetype* state, int address, int value, int is_store){
	int tag = address / (cache->sets * cache->block_size);
	int set = (address / cache->block_size) & (cache->sets - 1);
	int offset = address & (cache->block_size*cache->sets - 1);
	int location = -1;
	enum action_type action;

	/*Search for address tag*/
	for(int i = 0; i< cache->associativity; i++){
		if(*(cache->tag + set + i*cache->sets) == tag &&
			*(cache->valid + set + i*cache->sets) == 1){

			location = i;
		}
	}

	if(location == -1){
		/*Search for invalid spot first*/

		for(int i = 0; i< cache->associativity; i++){
			if(*(cache->valid + set + i*cache->sets) == 0){

				location = i;
			}
		}
		if(location == -1){
			/*LRU seach if there is no invalid spot*/
			for(int i = 0; i< cache->associativity; i++){
				if(*(cache->lru + set + i*cache->sets) == (cache->associativity - 1)){

					location = i;
				}
			}
			/*Eviction*/
			if(*(cache->dirty + set + location * cache->sets) == 1){
				/*bit is dirty so block must be stored to memory*/
				action = cache_to_memory;
				print_action(*(cache->tag + set + location * cache->sets) * cache->sets * cache->block_size + set * cache->block_size,cache->block_size,action);
				for(int i = 0;i< cache->block_size;i++){
					state->mem[*(cache->tag + set + location * cache->sets) * cache->sets * cache->block_size + set * cache->block_size + i]
					=*(cache->data + i + set * cache->block_size + location * cache->block_size * cache->sets);
				}
			} else {
				/*bit is clean so block can be thrown away*/
				action = cache_to_nowhere;
				print_action(*(cache->tag + set + location * cache->sets) * cache->sets * cache->block_size + set * cache->block_size,cache->block_size,action);
				for(int i = 0;i< cache->block_size;i++){
					*(cache->data + i + set * cache->block_size + location * cache->block_size * cache->sets) = 0;
				}
				*(cache->valid + set + location * cache->sets) = 0;
			}
		}
		/*Moving block from memory to cache*/
		action = memory_to_cache;
		print_action(tag * cache->sets * cache->block_size + set * cache->block_size,cache->block_size,action);
		for(int i = 0;i< cache->block_size;i++){
			*(cache->data + i + set * cache->block_size + location * cache->block_size * cache->sets)
			 = state->mem[tag * cache->sets * cache->block_size + set * cache->block_size + i];
		}
		*(cache->valid + set + location * cache->sets) = 1;
		*(cache->tag + set + location * cache->sets) = tag;

	}

	/*Adjust lru values with the one used getting 0*/
	int lru_value =  *(cache->lru + set + location *  cache->sets);
	for(int i = 0; i < cache->associativity; i++){
		if(*(cache->lru + set + i * cache->sets) < lru_value){
			*(cache->lru + set + i * cache->sets) = *(cache->lru + set + i * cache->sets) + 1;
		}
	}
	*(cache->lru + set + location * cache->sets) = 0;


	if(is_store == 0){
		action = cache_to_processor;
		print_action(address,1,action);
		return *(cache->data + offset + location*cache->sets*cache->block_size);
	} else {
		action = processor_to_cache;
		print_action(address,1,action);
		*(cache->data + offset + location * cache->block_size * cache->sets) = value;
		*(cache->dirty + set + location * cache->sets) = 1;//makes bit dirty.
		return 0;/*This value will not be used*/
	}

}

void clear_cache(cachetype* cache, statetype* state){
	for(int i = 0; i < cache->sets; i++){
		for(int j = 0; j < cache->associativity;j++){
			*(cache->valid + i + j * cache->sets) = 0;
			if(*(cache->dirty + i + j * cache->sets) == 1){
				enum action_type action = cache_to_memory;
				print_action(*(cache->tag + i + j * cache->sets) * cache->sets * cache->block_size + i * cache->block_size,cache->block_size,action);

				for(int k = 0;k< cache->block_size;k++){
					state->mem[*(cache->tag + i + j * cache->sets) * cache->sets * cache->block_size + i * cache->block_size + k]
					=*(cache->data + k + i * cache->block_size + j * cache->block_size * cache->sets);
				}

			}
		}
	}
}

void run(statetype* state, cachetype* cache){

	// Reused variables;
	int instr = 0;
	int regA = 0;
	int regB = 0;
	int offset = 0;
	int branchtarget = 0;
	int aluresult = 0;

	int total_instrs = 0;
	// Primary loop
	while(1){
		total_instrs++;

		//printstate(state);

		// Instruction Fetch
		instr = access_cache(cache,state,state->pc,0,0);

		/* check for halt */
		if (opcode(instr) == HALT) {
			//printf("machine halted\n");
			break;
		}

		// Increment the PC
		state->pc = state->pc+1;

		// Set reg A and B
		regA = state->reg[field0(instr)];
		regB = state->reg[field1(instr)];

		// Set sign extended offset
		offset = signextend(field2(instr));

		// Branch target gets set regardless of instruction
		branchtarget = state->pc + offset;
		/** 
		 *
		 * Action depends on instruction
		 *
		 **/
		// ADD
		if(opcode(instr) == ADD){
			// Add
			aluresult = regA + regB;
			// Save result
			state->reg[field2(instr)] = aluresult;
		}
		// NAND
		else if(opcode(instr) == NAND){
			// NAND
			aluresult = ~(regA & regB);
			// Save result
			state->reg[field2(instr)] = aluresult;
		}
		// LW or SW
		else if(opcode(instr) == LW || opcode(instr) == SW){
			// Calculate memory address
			aluresult = regB + offset;
			if(opcode(instr) == LW){
				// Load
				state->reg[field0(instr)] = access_cache(cache,state,aluresult,0,0);
			}else if(opcode(instr) == SW){
				// Store
				access_cache(cache,state,aluresult,regA,1);
				//state->mem[aluresult] = regA;
			}
		}// JALR
		else if(opcode(instr) == JALR){
			// Save pc+1 in regA
			state->reg[field0(instr)] = state->pc;
			//Jump to the address in regB;
			state->pc = state->reg[field1(instr)];
		}
		// BEQ
		else if(opcode(instr) == BEQ){
			// Calculate condition
			aluresult = (regA == regB);

			// ZD
			if(aluresult){
				// branch
				state->pc = branchtarget;
			}
		}
	} // While
	clear_cache(cache,state);
	//print_stats(total_instrs);
}

int main(int argc, char** argv){

	char *cvalue = NULL;
	char *bvalue = NULL;
	char *svalue = NULL;
	char *avalue = NULL;
	int index;
	int c;
	opterr = 0;
	FILE *fp;
	char str[80];
	char lines[65536][80];
	char *ret;

	while ((c = getopt (argc, argv, "f:b:s:a:")) != -1) {
		switch(c)
		{
			case 'f':
				cvalue = optarg;
				break;
			case 'b':
				bvalue = optarg;
				break;
			case 's':
				svalue = optarg;
				break;
			case 'a':
				avalue = optarg;
				break;
			case '?':
				if (optopt == 'f' || optopt == 'b' || optopt == 's' ||optopt == 'a' )
					fprintf(stderr, "Option -%c requires an argument.\n", optopt);
				else if (isprint (optopt))
					fprintf(stderr, "Unknown option '-%c'.\n", optopt);
				else {
					fprintf(stderr, "Unknown option character '\\x%x\n",optopt);
					return 1;
				}
			default:
				abort ();
		}
	}

	for (index = optind; index < argc; index++)
		printf ("Non-option argument %s\n", argv[index]);

	fp = fopen(cvalue, "r");
	if(fp == NULL) {
		perror("Error opening file\n");
		return (-1);
	}
	index = 0;
	while(fgets(str, 80, fp)!=NULL) {
		int j = 0;
		while(j<80) {
			lines[index][j] = str[j];
			j=j+1;
		}
		index = index + 1;
	}

	statetype* state = (statetype*)malloc(sizeof(statetype));
	state->pc = 0;
	memset(state->mem, 0, NUMMEMORY*sizeof(int));
	memset(state->reg, 0, NUMREGS*sizeof(int));
	state->nummemory = index;

	index = 0;
	while(index < state->nummemory){
		state->mem[index] = atoi(lines[index]);
		index = index + 1;
	}

	int block_size = atoi(bvalue);
	int number_of_sets = atoi(svalue);
	int associativity = atoi(avalue);

	cachetype* cache = (cachetype*)malloc(sizeof(cachetype));
	cache->valid = (int *)malloc(number_of_sets * associativity * sizeof(int));
	cache->dirty = (int *)malloc(number_of_sets * associativity * sizeof(int));
	cache->lru = (int *)malloc(number_of_sets * associativity * sizeof(int));
	cache->tag = (int *)malloc(number_of_sets * associativity * sizeof(int));
	cache->data = (int *)malloc(number_of_sets*block_size*associativity*sizeof(int));

	for(int i; i<number_of_sets; i++){
		for(int j; j<associativity; j++){
			*(cache->valid + i + j*number_of_sets) = 0;
			*(cache->dirty + i + j*number_of_sets) = 0;
			*(cache->tag + i + j*number_of_sets) = 0;
			*(cache->lru + i + j*number_of_sets) = associativity - 1;
		}
	}


	for(int i; i<number_of_sets*block_size; i++){
		for(int j; j<associativity; j++){
			*(cache->data + i + j*number_of_sets*block_size) = 0;
		}
	}
	cache->block_size = block_size;
	cache->sets = number_of_sets;
	cache->associativity = associativity;

	fclose(fp);

	/** Run the simulation **/
	run(state,cache);

	//free(state);
	//free(cvalue);
}
